/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: nawshadfarruque
 *
 * Created on February 6, 2017, 11:12 PM
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <algorithm>
//#include <set>
#include <map>

using namespace std;

/*
 * 1) store each transaction in a vector of vectors, so that it can looked up later for finding items.
 * 2) The following algorithm can be used for merging rows in any step, so generalize the function.
 * 3) To join two n-item-sets (where n > 1) see if at-least (n-1) item is same, if so, use the merge algorithm to merge them. 
 * Delete the two items which have min support less than 0.1%, also other n-item-sets which have n-1 member from
 * deleted item-set.
 * 4) Create an algorithm for generating n-item-sets at any point in this algorithm.

 */


string comma_seperated_list(vector<int> vector_of_ints){
    string s;
    for(int i=0; i<vector_of_ints.size(); i++){
        string delim = ", ";
        if(i==vector_of_ints.size()-1){
            delim = " ";
        }
        s = s + std::to_string(vector_of_ints[i])+delim;
    }
    return s;
}


int print_map(std::map<int,int> items) {
    for (std::map<int,int>::iterator it=items.begin(); 
        it!=items.end(); ++it){
        std::cout<< it->first<<"->"<<it->second<<endl;
    }
    return 0;
}


int write_map(std::map<int, int> one_items_map){
    
    ofstream myfile;
    myfile.open ("all_one_itemsets.txt");
    for (std::map<int,int>::iterator it=one_items_map.begin(); 
        it!=one_items_map.end(); ++it){
        myfile<< it->first<<"->"<<it->second<<endl;
    }
    return 0;
    
    myfile.close();
    
}

int print_map_with_vector_keys(std::map<vector<int> ,int> items){
    for (std::map<vector<int>,int>::iterator it=items.begin(); 
        it!=items.end(); ++it){
            for(int i=0; i<it->first.size(); i++){
                cout<<it->first[i]<<" ";
            }
            cout<<"-> "<<it->second<<endl;
    }
    return 0;
}

int write_L_final(std::map<vector<int> ,int> items, int count_itemsets){
        ofstream myfile;
        myfile.open ("all_freq_itemsets.txt");
    
        for(int i=2; i<=count_itemsets; i++){ 
            myfile<<"Frequent "<<i<<"itemsets: "<<endl;
            for (std::map<vector<int>,int>::iterator it=items.begin(); 
            it!=items.end(); ++it){   
                if(it->first.size() == i){
                    for(int j=0; j<it->first.size(); j++){
                        myfile<<it->first[j]<<" ";
                    }
                    myfile<<"-> "<<it->second<<endl;
                }
            }
        }
        myfile.close();
        return 0;
}


int print_vector_of_vectors(vector<vector<int> > items){
    for(int i=0; i<items.size(); i++){
        for(int j=0; j<items[i].size(); j++){
            cout<< items[i][j] <<" ";
        }
        cout<<endl;
    }
    return 0;
}


int print_vector(vector<int> items){
    for(int i=0; i<items.size(); i++){
        cout<<items[i]<<endl;
    }
    return 0;
}


void save(vector<int> l, vector<vector<int> > &vector_of_n_items){
    vector_of_n_items.push_back(l);
}

//The following code was collected from StackOverFlow and provided by the user Marcog
//http://stackoverflow.com/questions/4555565/generate-all-subsets-of-size-k-from-a-set

void subset(vector<int> arr, int left, int index, vector<int> &l, vector<vector<int> > &vector_of_n_items){
    if(left==0){
        save(l, vector_of_n_items);
        return;
    }
    for(int i=index; i<arr.size();i++){
        l.push_back(arr[i]);
        subset(arr,left-1,i+1,l, vector_of_n_items);
        l.pop_back();
    }
} 

std::map<int, int> gen_one_minsup_item_counts_map(std::map<int, int> one_item_counts_map, int support_count){
    std::map<int, int> one_minsup_items;
    for (std::map<int,int>::iterator it=one_item_counts_map.begin(); 
        it!=one_item_counts_map.end(); it++){
        int key = it->first;
        int value = it->second;
        if(one_item_counts_map[key] >= support_count){
            one_minsup_items[key] = value;
        }
    }
    return one_minsup_items;
}

int write_Tids_Items_to_file(std::map<int, vector<vector<int> > > Tids_Items){
    ofstream myfile;
    myfile.open ("Tid_Items.txt");
    
    for (std::map<int, vector<vector<int> > >::iterator it=Tids_Items.begin(); 
        it!=Tids_Items.end(); ++it){
        myfile<< it->first<<"->";
        vector<vector<int> > Tids = it->second;
        for(int i=0; i<Tids.size(); i++){
                for(int j=0; j<Tids[i].size(); j++){
                    myfile<<Tids[i][j]<<" ";
                }
                myfile<<endl;
        }
    }
    
    myfile.close();
    
    return 0;
}



// The following function getAllSubsets  was collected from StackOverFlow, ans provided by Ronald Rey
//http://stackoverflow.com/questions/728972/finding-all-the-subsets-of-a-set
vector< vector<int> > gen_all_subsets(vector<int> itemset)
{
    vector< vector<int> > subset;
    vector<int> empty;
    subset.push_back(empty);

    for (int i = 0; i < itemset.size(); i++)
    {
        vector< vector<int> > subsetTemp = subset;

        for (int j = 0; j < subsetTemp.size(); j++)
            subsetTemp[j].push_back( itemset[i] );

        for (int j = 0; j < subsetTemp.size(); j++)
            subset.push_back( subsetTemp[j] );
    }
    return subset;
}

double minconf(int count_numer, int count_denom){
    
    double minconf_value = (double)count_numer/(double)count_denom;
    return minconf_value;
}

int gen_strong_association_rule(std::map<vector<int>,int> L_final, 
                                int trans_size, std::map<int, int> one_minsup_item_counts_map, 
                                double conf_threshold){
    
    ofstream myfile;
    myfile.open ("strong_rules.txt");
    int str_rule_size = 0;
    
    for (std::map<vector<int>, int>::iterator it=L_final.begin(); it!=L_final.end(); ++it){
        vector<vector<int> > freq_sets_subsets = gen_all_subsets(it->first);
      
        for(int i=1; i<freq_sets_subsets.size()-1; i++){
             vector<int> diff;
             std::set_difference(it->first.begin(), it->first.end(), 
                                 freq_sets_subsets[i].begin(), freq_sets_subsets[i].end(),back_inserter(diff));
                
                vector<int> numer = it->first;
                vector<int> denom = freq_sets_subsets[i];
              
                
                int count_denom = 0;
                
                if(denom.size() == 1){
                    //myfile<<"L_final_count Denom:"<<one_minsup_item_counts_map[denom[0]]<<endl;
                    count_denom = one_minsup_item_counts_map[denom[0]];
                }else{
                    //myfile<<"L_final_count Denom:"<<L_final[denom]<<endl;
                    count_denom = L_final[denom];
                }
                
                int count_numer = 0;
                count_numer = L_final[numer];

                double minconf_val = minconf(count_numer, count_denom); 

                if(minconf_val >= conf_threshold){
                    vector<int> vector_of_ints;
                    for(int j=0; j<freq_sets_subsets[i].size(); j++){
                        //myfile<<freq_sets_subsets[i][j]<<" ";
                        vector_of_ints.push_back(freq_sets_subsets[i][j]);
                    }
                    myfile<<comma_seperated_list(vector_of_ints);
                    myfile<<"->";
                    vector_of_ints.clear();
                    for(int k=0; k<diff.size(); k++){
                        vector_of_ints.push_back(diff[k]);
                    }
                    myfile<<comma_seperated_list(vector_of_ints);
                    myfile<<"("<<std::fixed << std::setprecision(2)<<(double)count_numer/trans_size<<","<<minconf_val<<")"<<endl;
                    str_rule_size++;
                }
            }
        }
    
    myfile.close();
    return str_rule_size;
    
}

std::map<vector<int>, int> gen_two_minsup_itemsets_count_map(std::map<int, int> one_minsup_item_counts_map, 
                                                             vector< vector<int> > trans_vector, int support_count){
    std::map<vector<int>, int> two_itemsets_count_map, two_minsup_itemset_counts_map;
    vector<int> one_minsup_items;
    //put the one_minsup_item_counts_map in a vector
    for (std::map<int,int>::iterator it=one_minsup_item_counts_map.begin(); 
        it!=one_minsup_item_counts_map.end(); it++){
        one_minsup_items.push_back(it->first); 
    }
    
    //Join all frequent one-itemsets.
    for(int i=0; i<one_minsup_items.size(); i++){
        for(int j=i+1; j<one_minsup_items.size(); j++){
            vector<int> two_items;
            two_items.push_back(one_minsup_items[i]);
            two_items.push_back(one_minsup_items[j]);
            //cout<<"Two Items: ("<<two_items[0]<<","<<two_items[1]<<")"<<endl;
            two_itemsets_count_map[two_items] = 0;
        }
    }
    
    //cout<<"Two itemset count map size:"<<two_itemsets_count_map.size()<<endl;
    //cout<<"Print initialized two items map:"<<endl;
    //print_map_with_vector_keys(two_itemsets_count_map);
    
    //further prune this vector based on transaction based count
    for(int i=0; i<trans_vector.size(); i++){
        vector<int> lt;  
        vector<vector<int> > vector_of_n_sub_items;
        subset(trans_vector[i],2,0,lt,vector_of_n_sub_items);
        
        //update counts of the two_itemsets_map
        for(int j=0; j<vector_of_n_sub_items.size(); j++){
            //Check if the iem exist, then update
            if(two_itemsets_count_map.count(vector_of_n_sub_items[j])>0){
                int count = two_itemsets_count_map[vector_of_n_sub_items[j]];
                count++;
                two_itemsets_count_map[vector_of_n_sub_items[j]] = count;

                 //Check if that particular item occurs more than support_count
                if(two_itemsets_count_map[vector_of_n_sub_items[j]] >= support_count){
                    two_minsup_itemset_counts_map[vector_of_n_sub_items[j]] = 
                                        two_itemsets_count_map[vector_of_n_sub_items[j]];
                }
                
            }

        }
        
    }
    
    //Print two_itemset counts map
    //cout<<"Two itemsets map:"<<endl;
    //print_map_with_vector_keys(two_itemsets_count_map); 

    return  two_minsup_itemset_counts_map;
}


std::map<vector<int>, int> gen_n_minsup_itemsets_count_map(std::map<vector<int>, int> prev_items_counts_map, 
                                                             vector< vector<int> > trans_vector, int item_size, int support_count){
    std::map<vector<int>, int> n_itemsets_count_map, n_minsup_itemset_counts_map;
    vector<vector<int> > n_minsup_items;
    //put the n_minsup_item_counts_map in a vector
    
    for (std::map<vector<int>,int>::iterator it=prev_items_counts_map.begin(); 
        it!=prev_items_counts_map.end(); it++){
        n_minsup_items.push_back(it->first);
    }
    
    //cout<<"n-minsup vectors size:"<<n_minsup_items.size()<<endl;
    
    //Join all frequent one-itemsets.
    for(int i=0; i<n_minsup_items.size(); i++){
        for(int j=i+1; j<n_minsup_items.size(); j++){
            vector<int> union_vector, intersec_vector;
            
            //join them only if they have (n-1) common elements, then check if their sub vector is frequent.
            // if so then push them in n_items;
             set_intersection(n_minsup_items[i].begin(),n_minsup_items[i].end(),
                              n_minsup_items[j].begin(),n_minsup_items[j].end(),
                              back_inserter(intersec_vector));
            
            
            if((intersec_vector.size() == n_minsup_items[i].size()-1)){
                    set_union(n_minsup_items[i].begin(),n_minsup_items[i].end(),
                                 n_minsup_items[j].begin(),n_minsup_items[j].end(),back_inserter(union_vector));
            
                    vector<int> lt;  
                    vector<vector<int> > vector_of_n_sub_items;
                    subset(union_vector,union_vector.size()-1,0,lt,vector_of_n_sub_items); 

                    //find if any of the n_sub_items is not in n-1 (prev)_itemsets;
                    bool find = true;
                    for(int i=0; i<vector_of_n_sub_items.size(); i++){
                        if(prev_items_counts_map.count(vector_of_n_sub_items[i]) == 0){
                            find = false;
                            break;
                        }
                    }
                    //intialize new count map with all 1s.
                    n_itemsets_count_map[union_vector] = 0;  
            }
        }
    }
    
    //cout<<"n-item-set count map size:"<<n_itemsets_count_map.size()<<endl;
    
    //further prune this vector based on transaction based count
    for(int i=0; i<trans_vector.size(); i++){
        vector<int> lt;  
        vector<vector<int> > vector_of_n_sub_items;
        subset(trans_vector[i],item_size,0,lt,vector_of_n_sub_items);
        
        //update counts of the two_itemsets_map
        for(int j=0; j<vector_of_n_sub_items.size(); j++){
            //Check if the iem exist, then update
            if(n_itemsets_count_map.count(vector_of_n_sub_items[j])>0){
                int count = n_itemsets_count_map[vector_of_n_sub_items[j]];
                count++;
                n_itemsets_count_map[vector_of_n_sub_items[j]] = count;
                
                 //Check if that particular item occurs more than support_count
                if(n_itemsets_count_map[vector_of_n_sub_items[j]] >= support_count){
                    n_minsup_itemset_counts_map[vector_of_n_sub_items[j]] = 
                                        n_itemsets_count_map[vector_of_n_sub_items[j]];
                }
            }   
        }   
    }
    return  n_minsup_itemset_counts_map;
}




int freq_itemset_generator(string filename, double sup_threshold, double conf_threshold){
    //read the file and store all one items, sort them and store in a vector and also, save all
    //the transactions in a vector of vectors.
    
    cout<<"filename:"<<filename<<endl;
    cout<<"Sup threshold:"<<sup_threshold<<endl;
    cout<<"Conf_threshold:"<<conf_threshold<<endl;
    
    std::ifstream file(filename);
    std::string line; 
    string item;
    vector<int> indv_items_vector, one_unique_items;
    vector< vector<int> > trans_vector;
    std::map<int, int> one_item_counts_map;
    
    while (std::getline(file, line)){
        indv_items_vector.clear();
        istringstream iss(line, istringstream::in);
        while( iss >> item ) {  
            int int_item = std::stoi(item); 
            if(one_item_counts_map.count(int_item) > 0){
                one_item_counts_map[int_item]++; //count increased
            }else{
                one_item_counts_map[int_item] = 1;
            }
            indv_items_vector.push_back(int_item);
        }
        trans_vector.push_back(indv_items_vector);
    }
    
    ofstream myfile;
    myfile.open ("stats.txt");
    myfile<<"Operating on file: "<<filename<<endl;
    
    
    myfile<<"Transaction Size: "<<trans_vector.size()<<endl;
    
    int support_count = (int)trans_vector.size()*(sup_threshold);
    
    myfile<<"Support count:"<<support_count<<endl;
    
    std::map<int, int> one_minsup_item_counts_map = gen_one_minsup_item_counts_map(one_item_counts_map, support_count);
    
    //print_map(one_minsup_item_counts_map);
    
    myfile<<"Frequent 1 itemset size: "<<one_minsup_item_counts_map.size()<<endl; 
    
    //cout<<"One minsup map write to file"<<endl;
    
    //write_map(one_minsup_item_counts_map);
    
    //Now we have frequent 1 itemsets. generate two itemsets map.
    
    std::map<vector<int>, int> two_minsup_itemsets_counts_map = 
                gen_two_minsup_itemsets_count_map(one_minsup_item_counts_map, 
                                                  trans_vector, support_count);
    
    myfile<<"Frequent 2 itemset size: "<<two_minsup_itemsets_counts_map.size()<<endl;
    
    std::map<vector<int>, int> L_minsup = two_minsup_itemsets_counts_map;
    
    std::map<vector<int>, int> L_final = L_minsup;
    
    //L_minsup = two_minsup_itemsets_counts_map;
    //L_final = L_minsup; // fill up L_final with all two-freq itemsets
    int count = 3;
    
    int start_s=clock();
    
    while(L_minsup.size() > 0){
        L_minsup = gen_n_minsup_itemsets_count_map(L_minsup, trans_vector, count, support_count);
   
        myfile<<"Number of frequent "<<count<<"_itemsets: "<<L_minsup.size()<<endl;
        //fill up L_final with all n-freq itemsets
        for (std::map<vector<int>,int>::iterator it=L_minsup.begin(); it!=L_minsup.end(); ++it){
            L_final[it->first] = it->second;  
        }
        
        count++;  
    }
    
    int stop_s=clock();
    myfile << "execution time: " << (stop_s-start_s)/double(CLOCKS_PER_SEC)*1000 <<" milliseconds"<< endl;
    myfile<<"Number of strong association rules: "<<gen_strong_association_rule(L_final, trans_vector.size(), one_minsup_item_counts_map, conf_threshold)<<endl;
    myfile<<"total frequent-itemset map size: "<<L_final.size()+one_minsup_item_counts_map.size()<<endl;
   // cout<<"Writing to file all frequent itemsets"<<endl;
    //write_L_final(L_final, count);
    cout<<"Complete!!!"<<endl;
    
    myfile.close();
    
    //Loop through each of the frequent itemsets in the L_Final
    
    // For each L_final generate the subset s. 
    // Calculate confidence, if confidence >= 80% then save it
    gen_strong_association_rule(L_final, trans_vector.size(), one_minsup_item_counts_map, conf_threshold);
    return 0;
}

int test_codes(){
    
    vector<int> dummy_itemset;
    dummy_itemset.push_back(1);
    dummy_itemset.push_back(2);
    dummy_itemset.push_back(3);
    dummy_itemset.push_back(4);
    dummy_itemset.push_back(5);
    dummy_itemset.push_back(6);
    dummy_itemset.push_back(7);
    dummy_itemset.push_back(8);
    dummy_itemset.push_back(9);
    dummy_itemset.push_back(10);
    dummy_itemset.push_back(11);
    
     
    vector<int> lt;  
    vector<vector<int> > vector_of_n_sub_items;
    subset(dummy_itemset,2,0,lt,vector_of_n_sub_items); 

    cout<<vector_of_n_sub_items.size()<<endl;
    
    
    return 0;
}



int main(int argc, char** argv) {
     
   //Call freq_itemset_generator function with necessary parameters, such as 
   // stated by the question.
   if(argc < 4) {
        cout<<"You must provide minimum 3 arguments"<<endl;
        exit(0);
    }else if (argc >= 4 && argc < 5 ){
         string file_name = argv[1];
         double support =  strtod (argv[2], NULL);
         double confidence = strtod (argv[3], NULL);
         
         freq_itemset_generator(file_name, support, confidence);
    }
    
    //test_codes();
    return 0;
    
}  

